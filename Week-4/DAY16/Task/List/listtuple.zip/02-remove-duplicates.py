l=[1,2,3,4,67,45,89,23,67,89,98,67,89,23,22,23]
print("Original List:",l)

l=[*set(l)]
print("List after removing duplicates:",l)